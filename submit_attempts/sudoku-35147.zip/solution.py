from utils import *

assignments = []

def assign_value(values, box, value):
    """
    Please use this function to update your values dictionary!
    Assigns a value to a given box. If it updates the board record it.
    """

    # Don't waste memory appending actions that don't actually change any values
    if values[box] == value:
        return values

    values[box] = value
    if len(value) == 1:
        assignments.append(values.copy())
    return values

def naked_twins(values):
    """Eliminate values using the naked twins strategy.
    Args:
        values(dict): a dictionary of the form {'box_name': '123456789', ...}

    Returns:
        the values dictionary with the naked twins eliminated from peers.
    """
    naked_twins_list = []
    # Find all instances of naked twins
    for unit in all_units:
        for unit_peer in unit:
            if len(values[unit_peer]) == 2:
                for up in unit:
                    if values[up] == values[unit_peer]:
                        if up != unit_peer:
                            naked_twins_list.append((unit_peer, up, unit))
                            break

    # Eliminate the naked twins as possibilities for their peers
    for nt in naked_twins_list:
        for peer in nt[2]:
            if peer != nt[0] and peer != nt[1]:
                values[peer] = values[peer].replace(values[nt[0]][0], '')
                values[peer] = values[peer].replace(values[nt[0]][1], '')

    return values

#def cross(A, B):
#    "Cross product of elements in A and elements in B."
#    return [row + col for row in A for col in B]

def grid_values(grid):
    """
    Convert grid into a dict of {square: char} with '123456789' for empties.
    Args:
        grid(string) - A grid in string form.
    Returns:
        A grid in dictionary form
            Keys: The boxes, e.g., 'A1'
            Values: The value in each box, e.g., '8'. If the box has no value, then the value will be '123456789'.
    """
    assert len(grid) == 81, 'Input grid must be a string of lenght 81 (9x9)'
    values = {}
    for i, box in enumerate(boxes):
        values[box] = (grid[i] if grid[i] != '.' else '123456789')

    return values

def display(values):
    """
    Display the values as a 2-D grid.
    Args:
        values(dict): The sudoku in dictionary form
    """
    width = 1+max(len(values[s]) for s in boxes)
    line = '+'.join(['-'*(width*3)]*3)
    for r in rows:
        print(''.join(values[r+c].center(width)+('|' if c in '36' else '')
                      for c in cols))
        if r in 'CF': print(line)
    return

def eliminate(values):
    """
    Strategy that eliminates possibilities from peers for the boxes with final value
    Args:
        values(dict): The sudoku in dictionary form
    Returns:
        values(dict): The reduced sudoku in dictionary form
    """
    for box in values:
        if len(values[box]) == 1:
            for peer in peers[box]:
                if len(values[peer]) > 1:
                    values[peer] = values[peer].replace(values[box], '')
    return values

def only_choice(values):
    """
    Strategy that finds the final value for the boxes with multiple possibilities
        that are the only ones within a given unit that can have that value
    Args:
        values(dict): The sudoku in dictionary form
    Returns:
        values(dict): The reduced sudoku in dictionary form
    """
    digits = '123456789'
    for unit in all_units:
        for digit in digits:
            dboxes = [box for box in unit if digit in values[box]]
            if len(dboxes) == 1:
                assign_value(values, dboxes[0], digit)
                #values[dboxes[0]] = digit
    return 

def reduce_puzzle(values):
    """
    A wrapping method that takes care of calling all the reduction strategies implemented
    Args:
        values(dict): The sudoku in dictionary form
    Returns:
        values(dict): The reduced sudoku in dictionary form
    """
    # The reduction consist now on 3 strategies:
    #   1. Elimination
    #   2. Only choice
    #   3. Naked Twins strategy

    # Reduce the puzzle as much as possible by making sure we stop
    #   when no more reductions can be performed
    stalled = False
    while not stalled:
        # Compute number of boxes with final values before reduction
        before = len([box for box in values.keys() if len(values[box]) == 1])
        # STEP1. Eliminate possibilities from peer boxes
        eliminate(values)
        ##DEBUG print("After elimination:", values)
        # STEP2. Determine if there is any box that can be set as final
        only_choice(values)
        ##DEBUG print("After only choice:", values)
        # STEP3. Apply the naked_twins strategy
        naked_twins(values)
        # Compute number of boxes with final value after reduction
        after = len([box for box in values.keys() if len(values[box]) == 1])
        # If before is equal to after (no reduction has happened in this iteration)
        #   we are stalled and we have to exit the while loop
        if before == after:
            stalled = True
    return values

def search(values):
    # First call the strategies to reduce our puzzle
    values = reduce_puzzle(values)
    ##DEBUG print("Reduction:", values)
    # If we managed to solve the puzzle by the reduction, return the solution
    if all(len(values[box]) == 1 for box in values.keys()):
        ##DEBUG print("SOLVED")
        return values
    # If we havent found a solution yet, find one of the boxes with less possibilities left
    n, the_box = min((len(values[box]), box) for box in values.keys() if len(values[box]) > 1)
    # And enter the recursion for each of the possibilities
    for value in values[the_box]:
        new_values = values.copy()
        new_values[the_box] = value
        attempt = search(new_values)
        if attempt:
            return attempt

def solve(grid):
    """
    Find the solution to a Sudoku grid.
    Args:
        grid(string): a string representing a sudoku grid.
            Example: '2.............62....1....7...6..8...3...9...7...6..4...4....8....52.............3'
    Returns:
        The dictionary representation of the final sudoku grid. False if no solution exists.
    """
    ##DEBUG print(grid)
    # 1. Setting up and Encoding the input grid into the board 
    values = grid_values(grid)

    # 2. Explore all the options by calling the search recursive method 
    #   (This method will be responsible of calling the reduce_puzzle
    #    strategies)
    values = search(values)
    ##DEBUG print("SOLUTION:", values)
    ##DEBUG print("SOLVED IN ITERATION:", iterations)

    return values

if __name__ == '__main__':
    #easy_sudoku_grid = "..3.2.6..9..3.5..1..18.64....81.29..7.......8..67.82....26.95..8..2.3..9..5.1.3.."
    #hard_sudoku_grid = '4.....8.5.3..........7......2.....6.....8.4......1.......6.3.7.5..2.....1.4......'
    diag_sudoku_grid = '2.............62....1....7...6..8...3...9...7...6..4...4....8....52.............3'
    display(solve(diag_sudoku_grid))

    try:
        from visualize import visualize_assignments
        visualize_assignments(assignments)

    except SystemExit:
        pass
    except:
        print('We could not visualize your board due to a pygame issue. Not a problem! It is not a requirement.')
