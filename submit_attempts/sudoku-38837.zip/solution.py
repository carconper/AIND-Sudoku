#from utils import *

assignments = []

rows = 'ABCDEFGHI'
cols = '123456789'

def cross(A, B):
    "Cross product of elements in A and elements in B."
    return [row + col for row in A for col in B]

# boxes contains all the coordenates of our 9x9 grid
boxes = cross(rows, cols)
# row_units contains all the row units
row_units = [[boxes[i + j * 9] for i in range(9)] for j in range(9)]
# col_units contains all the column units
col_units = [[boxes[i * 9 + j] for i in range(9)] for j in range(9)]
# sq_units contains all the 3x3 square units
sq_units = [cross(rg, cg) for rg in ['ABC', 'DEF', 'GHI'] for cg in ('123', '456', '789')]
# diag_units contains the 2 big diagonal units
diag1 = [rows[i] + cols[i] for i in range(len(rows))]
diag2 = [rows[len(rows) - 1 - i] + cols[i] for i in range(len(rows))]
diag_units = [diag1, diag2]
# all_units contains all the units in our 9x9 grid
all_units = row_units + col_units + sq_units + diag_units
#all_units = row_units + col_units + sq_units
# box_units is a dictionary in which the key references each box
#   and the value represents a list of list containing all the units
#   that box is part of
box_units = dict((box, [unit for unit in all_units if box in unit] )for box in boxes)
# peers is a dictionary in which the key references each box in the grid
#   and the value is a list of peer boxes of the key box
peers = dict((box, set(sum(box_units[box], [])) - set([box])) for box in boxes)
#print(diag_units)
#print(peers['A1'])
#print(peers['D1'])
#print(peers['E5'])
#print(peers['H4'])
#for box in diag1 + diag2:
#    print("Box/peers:", box, len(peers[box]), peers[box])
#print((peers[box], len(peers[box])) for box in diag1)

def assign_value(values, box, value):
    """
    Please use this function to update your values dictionary!
    Assigns a value to a given box. If it updates the board record it.
    """

    # Don't waste memory appending actions that don't actually change any values
    if values[box] == value:
        return values

    values[box] = value
    if len(value) == 1:
        assignments.append(values.copy())
    return values


def display(values):
    """
    Display the values as a 2-D grid.
    Args:
        values(dict): The sudoku in dictionary form
    """
    width = 1+max(len(values[s]) for s in boxes)
    line = '+'.join(['-'*(width*3)]*3)
    for r in rows:
        print(''.join(values[r+c].center(width)+('|' if c in '36' else '')
                      for c in cols))
        if r in 'CF': print(line)
    return


def grid_values(grid):
    """
    Convert grid into a dict of {square: char} with '123456789' for empties.
    Args:
        grid(string) - A grid in string form.
    Returns:
        A grid in dictionary form
            Keys: The boxes, e.g., 'A1'
            Values: The value in each box, e.g., '8'. If the box has no value, then the value will be '123456789'.
    """
    assert len(grid) == 81, 'Input grid must be a string of lenght 81 (9x9)'
    values = {}
    for i, box in enumerate(boxes):
        values[box] = (grid[i] if grid[i] != '.' else '123456789')
    #print(values)

    return values


def eliminate(values):
    """
    Strategy that eliminates possibilities from peers for the boxes with final value
    Args:
        values(dict): The sudoku in dictionary form
    Returns:
        values(dict): The reduced sudoku in dictionary form
    """
    solved_values = [box for box in values.keys() if len(values[box]) == 1]
    for box in solved_values:
        digit = values[box]
        for peer in peers[box]:
            values[peer] = values[peer].replace(digit,'')
    return values

def only_choice(values):
    """
    Strategy that finds the final value for the boxes with multiple possibilities
        that are the only ones within a given unit that can have that value
    Args:
        values(dict): The sudoku in dictionary form
    Returns:
        values(dict): The reduced sudoku in dictionary form
    """
    digits = '123456789'
    for unit in all_units:
        for digit in digits:
            dboxes = [box for box in unit if digit in values[box]]
            if len(dboxes) == 1:
                values = assign_value(values, dboxes[0], digit)
                #for peer in peers[dboxes[0]]:
                #    if len(values[peer]) > 1:
                #        values[peer].replace(digit, '')
                #if dboxes[0] == 'H4':
                #    print("VALUES for H4 peers:", list((t, values[t]) for t in unit))
                #values[dboxes[0]] = digit
    return values


def naked_twins(values):
    """Eliminate values using the naked twins strategy.
    Args:
        values(dict): a dictionary of the form {'box_name': '123456789', ...}

    Returns:
        the values dictionary with the naked twins eliminated from peers.
    """
    naked_twins_list = []
    # Find all instances of naked twins
    for unit in all_units:
        for unit_peer in unit:
            if len(values[unit_peer]) == 2:
                for up in unit:
                    if values[up] == values[unit_peer]:
                        if up != unit_peer:
                            naked_twins_list.append((unit_peer, up, unit))
                            break
    #print("Naked_twins_all:", naked_twins_list)
#    print("New set of NTs")
#    print("==============")
#    for elem in naked_twins_list:
#        print("NT:", elem)
#        print("Values:", values[elem[0]], values[elem[1]])
#        print("----------------------")
    # Eliminate the naked twins as possibilities for their peers
    for nt in naked_twins_list:
        if len(values[nt[0]]) == 2 and len(values[nt[1]]) == 2:
            for peer in nt[2]:
                if peer != nt[0] and peer != nt[1]:
                    values[peer] = values[peer].replace(values[nt[0]][0], '')
                    values[peer] = values[peer].replace(values[nt[0]][1], '')

    return values


def reduce_puzzle(values):
    """
    A wrapping method that takes care of calling all the reduction strategies implemented
    Args:
        values(dict): The sudoku in dictionary form
    Returns:
        values(dict): The reduced sudoku in dictionary form
    """
    # The reduction consist now on 3 strategies:
    #   1. Elimination
    #   2. Only choice
    #   3. Naked Twins strategy

    # Reduce the puzzle as much as possible by making sure we stop
    #   when no more reductions can be performed
    stalled = False
    while not stalled:
        # Compute number of boxes with final values before reduction
        before = len([box for box in boxes if len(values[box]) == 1])
        # STEP1. Eliminate possibilities from peer boxes
        values = eliminate(values)
        ##DEBUG print("After elimination:", values)
        # STEP2. Determine if there is any box that can be set as final
        values = naked_twins(values)
        values = only_choice(values)
        ##DEBUG print("After only choice:", values)
        # STEP3. Apply the naked_twins strategy
        #naked_twins(values)
        # Compute number of boxes with final value after reduction
        after = len([box for box in boxes if len(values[box]) == 1])
        # If before is equal to after (no reduction has happened in this iteration)
        #   we are stalled and we have to exit the while loop
        if before == after:
            stalled = True
        if len([box for box in values.keys() if len(values[box]) == 0]):
            #print("EMPTY VALUES!!!", ([box for box in values.keys() if len(values[box]) == 0]))
            return False
    return values

def search(values):
    # First call the strategies to reduce our puzzle
    values = reduce_puzzle(values)
    ##DEBUG print("Reduction:", values)
    if values is False:
        return False
    # If we managed to solve the puzzle by the reduction, return the solution
    if all(len(values[box]) == 1 for box in boxes):
        ##DEBUG print("SOLVED")
        return values
    # If we havent found a solution yet, find one of the boxes with less possibilities left
    n, box = min((len(values[box]), box) for box in boxes if len(values[box]) > 1)
    # And enter the recursion for each of the possibilities
    for value in values[box]:
        new_values = values.copy()
        new_values[box] = value
        attempt = search(new_values)
        if attempt:
            return attempt

def solve(grid):
    """
    Find the solution to a Sudoku grid.
    Args:
        grid(string): a string representing a sudoku grid.
            Example: '2.............62....1....7...6..8...3...9...7...6..4...4....8....52.............3'
    Returns:
        The dictionary representation of the final sudoku grid. False if no solution exists.
    """
    ##DEBUG print(grid)
    # 1. Setting up and Encoding the input grid into the board 
    values = grid_values(grid)

    # 2. Explore all the options by calling the search recursive method 
    #   (This method will be responsible of calling the reduce_puzzle
    #    strategies)
    values = search(values)
    ##DEBUG print("SOLUTION:", values)
    ##DEBUG print("SOLVED IN ITERATION:", iterations)

    return values

if __name__ == '__main__':
    easy_sudoku_grid = "..3.2.6..9..3.5..1..18.64....81.29..7.......8..67.82....26.95..8..2.3..9..5.1.3.."
    hard_sudoku_grid = '4.....8.5.3..........7......2.....6.....8.4......1.......6.3.7.5..2.....1.4......'
    diag_sudoku_grid = '2.............62....1....7...6..8...3...9...7...6..4...4....8....52.............3'
    diag_sudoku_grid = '9.1....8.8.5.7..4.2.4....6...7......5..............83.3..6......9................'
    diag_sudoku_grid = '......9.....6.....3.........91.2..7....1.....5.....2.1......4..2..4..5...7.....1.'
    #display(grid_values(diag_sudoku_grid))
    display(solve(diag_sudoku_grid))
    #display(solve(easy_sudoku_grid))

    try:
        from visualize import visualize_assignments
        visualize_assignments(assignments)

    except SystemExit:
        pass
    except:
        print('We could not visualize your board due to a pygame issue. Not a problem! It is not a requirement.')
